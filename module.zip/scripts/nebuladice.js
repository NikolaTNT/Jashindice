Hooks.once('diceSoNiceInit', (dice3d) => {
    dice3d.addTexture("Nebula", {
        name: "Nebula",
        composite: "source-over",
        source: "images/nebula.webp",
    });

});
